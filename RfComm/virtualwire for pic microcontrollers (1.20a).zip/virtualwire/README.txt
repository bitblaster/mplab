Simplified Virtual Wire compatible library for PIC microcontrollers.

Tested on PIC 16F628.

It is based on the original VirtualWire 1.20 available for Arduino at
http://www.airspayce.com/mikem/arduino/